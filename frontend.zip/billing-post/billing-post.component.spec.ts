import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingPostComponent } from './billing-post.component';

describe('BillingPostComponent', () => {
  let component: BillingPostComponent;
  let fixture: ComponentFixture<BillingPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
