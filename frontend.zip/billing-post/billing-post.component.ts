import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-post',
  templateUrl: './billing-post.component.html',
  styleUrls: ['./billing-post.component.css']
})
export class BillingPostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
