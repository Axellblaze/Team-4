import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingDonComponent } from './billing-don.component';

describe('BillingDonComponent', () => {
  let component: BillingDonComponent;
  let fixture: ComponentFixture<BillingDonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingDonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingDonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
