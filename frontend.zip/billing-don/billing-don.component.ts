import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-don',
  templateUrl: './billing-don.component.html',
  styleUrls: ['./billing-don.component.css']
})
export class BillingDonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
