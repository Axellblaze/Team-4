import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileDonComponent } from './profile-don.component';

describe('ProfileDonComponent', () => {
  let component: ProfileDonComponent;
  let fixture: ComponentFixture<ProfileDonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileDonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileDonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
