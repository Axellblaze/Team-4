import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-don',
  templateUrl: './profile-don.component.html',
  styleUrls: ['./profile-don.component.css']
})
export class ProfileDonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
