import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PostpaidComponent } from './postpaid/postpaid.component';
import { PrepaidComponent } from './prepaid/prepaid.component';
import { DongleComponent } from './dongle/dongle.component';
import { ProfileComponent } from './profile/profile.component';
import { PlansComponent } from './plans/plans.component';
import { StatusComponent } from './status/status.component';
import { RechargeComponent } from './recharge/recharge.component';
import { HelpComponent } from './help/help.component';
import { ProductsComponent } from './products/products.component';
import { BillingPostComponent } from './billing-post/billing-post.component';
import { ProductsPostComponent } from './products-post/products-post.component';
import { HelpPostComponent } from './help-post/help-post.component';
import { RechargePostComponent } from './recharge-post/recharge-post.component';
import { StatusPostComponent } from './status-post/status-post.component';
import { ProfilepostComponent } from './profilepost/profilepost.component';
import { PlansPostComponent } from './plans-post/plans-post.component';
import { ProfileDonComponent } from './profile-don/profile-don.component';
import { PlansDonComponent } from './plans-don/plans-don.component';
import { StatusDonComponent } from './status-don/status-don.component';
import { RechargeDonComponent } from './recharge-don/recharge-don.component';
import { HelpDonComponent } from './help-don/help-don.component';
import { ProductsDonComponent } from './products-don/products-don.component';
import { BillingDonComponent } from './billing-don/billing-don.component';
import { NetworkspeedComponent } from './networkspeed/networkspeed.component';
import { RegistrationComponent } from './registration/registration.component';



const routes: Routes = [
//   {path: 'login', component: LoginComponent},
//   {path: '', component: LoginComponent},
// {path:'register',component:RegistrationComponent},
{path:'prepaid',component:PrepaidComponent},
{path:'billing-don',component:BillingDonComponent},
{path:'billing-post',component:BillingPostComponent},
{path:'',component:ProfileDonComponent},
]

  
  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
